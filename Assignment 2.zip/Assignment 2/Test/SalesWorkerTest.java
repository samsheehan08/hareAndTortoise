import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


/**
 * Test Class for the SalesWorker class
 * 
 * @author Samantha Sheehan
 */
public class SalesWorkerTest {
	
	/*
	 * Finish this in lab what else requires testing??
	 * Calculate salary-first work it out!!
	 * Test constructor validation on salesBonus
	 * */
	
	private SalesWorker sales1, sales2,invalidSales;
	
	@Before
	public void setUp() throws Exception {
		sales1 = new SalesWorker("Joe","McDonnell",10,15.5);
		sales2 = new SalesWorker("James","Connelly",8.50,10);
		invalidSales = new SalesWorker("Kate", "Feck", -1,-1);
	}
	
	/**
	 * Test method for SalesWorker constructor
	 */
	@Test
	public void testConstructor() {
		//test on valid data
		assertEquals("Joe", sales1.getFirstName());
		assertEquals("McDonnell", sales1.getSecondName());
		assertEquals(10, sales1.getHourlyRate(), 0.01);
		//test on invalid data
		assertEquals(0, invalidSales.getHourlyRate(), 0.01);

	}
	
	/**
	 * Test method for getters in Sales Worker
	 */
	@Test
	public void testGettersValidData() {
		assertEquals("Joe",sales1.getFirstName());
		assertEquals("McDonnell",sales1.getSecondName());
		assertEquals(8.50, sales2.getHourlyRate(), 0.01);	
		assertEquals(15.50,sales1.getSalesBonus(),0.01);;
	}
	
	
	/**
	 * Test method for setters in Sales Worker
	 */
	@Test
	public void testSetters(){
		assertEquals(sales2.getFirstName(), "James");
		sales2.setFirstName("John");
		assertEquals(sales2.getFirstName(),"John");
		assertEquals("McDonnell",sales1.getSecondName());
		sales1.setSecondName("Eskimo");
		assertEquals(sales1.getSecondName(),"Eskimo");
		assertEquals(8.50, sales2.getHourlyRate(), 0.01);
		sales2.setHourlyRate(10.00);
		assertEquals(10.00, sales2.getHourlyRate(), 0.01);
		assertEquals(15.50,sales1.getSalesBonus(),0.01);
		sales1.setSalesBonus(12);
		assertEquals(12,sales1.getSalesBonus(),0.01);
		
	}
	
	/**
	 * Test method for get/setSalesBonus. Testing invalid
	 * data to confirm validation
	 */
	@Test
	public void testGetSetSalesBonus() {
		assertEquals(15.5, sales1.getSalesBonus(), 0.01);
        sales1.setSalesBonus(-1);
		assertEquals(15.5, sales1.getSalesBonus(), 0.01);
        sales1.setSalesBonus(21);
        assertEquals(15.5, sales1.getSalesBonus(), 0.01);
        sales1.setSalesBonus(0);
        assertEquals(0, sales1.getSalesBonus(), 0.01);
	}
	
	/**
	 * Test method for getHourlyRate and setHourlyRate. Testing invalid data.
	 */
	@Test
	public void testGetSetHourlyRate() {
		assertEquals(10, sales1.getHourlyRate(), 0.01);
        sales1.setHourlyRate(-1);
		assertEquals(10, sales1.getHourlyRate(), 0.01);
        sales1.setHourlyRate(0);
        assertEquals(0, sales1.getHourlyRate(), 0.01);
        sales1.setHourlyRate(20);
        assertEquals(20,sales1.getHourlyRate(), 0.01);
	}
	
	/**
	 * Test method for calculateSalary()
	 */
	@Test
	public void testCalculateSalary() {
		assertEquals(415.8, sales1.calculateSalary(36), 0.01);
		assertEquals(537.075, sales1.calculateSalary(42), 0.01);
		assertEquals(397.375, sales2.calculateSalary(40), 0.01);
		assertEquals(350.625, sales2.calculateSalary(37.5), 0.01);
	}

	

}
