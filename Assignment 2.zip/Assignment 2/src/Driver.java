import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
public class Driver {
	
	private Scanner input;
	private List<Employee> employees;
	
	public Driver(){	
		input=new Scanner(System.in);
		employees=new ArrayList<Employee>();
	}
	
	public static void main (String args[]){
		Driver d =new Driver();
		try{
        	d.load();
	  	}
	  	catch(Exception e){
	  		System.out.println("Error reading from file: " + e);
	  	}
        d.runMenu();       
    }
	
	private int mainMenu(){
		System.out.println("Menu");
		System.out.println("----");
		System.out.println("1) Add an Employee");
		System.out.println("2) List Employees");
		System.out.println("3) Edit Employee");
		System.out.println("4) Remove an Employee");
		System.out.println("---------------------");
		System.out.println("5) Salary Menu");
		System.out.println("7) Department Menu");
		System.out.println("0) Exit");
		System.out.println("------------------");
		boolean goodInput = false;
	    int option=0;
	    do{
			try{
				option= input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
    	return option;
	}
	
	private void runMenu(){
        int option = mainMenu();
        while (option != 0){

            switch (option){
               case 1:    addEmployee();
               			  try{
               				  save();
               			  }
               			  catch(Exception e){
               				  System.out.println("Error writing to file: " + e);
               			  }
                          break;
               case 2:    runListEmployeesMenu();
                          break;
               case 3:	  runEditEmployeeMenu();
            	   		  try{
            	   			  save();
            	   		  }
            	   		  catch(Exception e){
			  			  System.out.println("Error writing to file: " + e);
            	   		  }
            	   		  break;
               case 4:    removeEmployee();
               			  try{
               				  save();
               			  }
               			  catch(Exception e){
               				  System.out.println("Error writing to file: " + e);
               			  }
               			  break;
               case 5:    runCalculateSalaryMenu();
 			  			  break;
               case 6:    
 			  			  break;
               case 7:    runDeptMenu();
		    			  break;
            }
            
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            
            option = mainMenu();
        }
        
        System.out.println("Exiting... bye");
        try{
	  			save();
  		  }
  		  catch(Exception e){
  			  System.out.println("Error writing to file: " + e);
  		  }
        System.exit(0);
    }
	
	private void addEmployee(){
		input.nextLine();
		System.out.print("Enter the Employee's First Name:  ");
	    String firstName = input.nextLine();
	    System.out.print("Enter the Employee's Second Name:  ");
	    String secondName = input.nextLine();
	    System.out.print("Enter the hourlyRate:  ");
	    boolean goodInput = false;
	    double hourlyRate=0;
	    do{
			try{
				hourlyRate= input.nextDouble();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
	    addWorkerOption(firstName, secondName, hourlyRate);
	}
	
	private void addWorkerOption(String firstName, String secondName, double hourlyRate){
		input.nextLine();
		System.out.println(
			  "\n 1) Manager"
			+ "\n 2) Sales worker"
			+ "\n 3) Temp worker");
		boolean goodInput = false;		
		int choices = 0;
		do{
		try{
			choices=input.nextInt();
			goodInput=true;
		}
		catch (Exception e){
			input.nextLine();
			System.out.println("Number required - you entered text");
		}
		}	while(!goodInput);
		if (choices==1){
			System.out.println("Enter the Managers weekly bonus:");			
			boolean getDouble = false;
		    double managerBonus=0;
		    do{
				try{
					managerBonus= input.nextDouble();
					getDouble=true;
				}
				catch (Exception e){
					input.nextLine();
					System.out.println("Number required - you entered text");
				}
			}while(!getDouble);
			employees.add(new Manager(firstName, secondName, hourlyRate, managerBonus));
		}
		else if(choices==2){
			System.out.println("Enter the Employees sales bonus(%):");
			boolean getDouble = false;
		    double salesBonus=0;
		    do{
				try{
					salesBonus= input.nextDouble();
					getDouble=true;
				}
				catch (Exception e){
					input.nextLine();
					System.out.println("Number required - you entered text");
				}
			}while(!getDouble);
			employees.add(new SalesWorker(firstName, secondName, hourlyRate, salesBonus));
		}
		else if(choices==3){
			employees.add(new TempWorker(firstName, secondName, hourlyRate));
		}
		else{
			System.out.println("This is an invalid option please choose 1, 2 or 3.");
			addWorkerOption(firstName, secondName, hourlyRate);
		}
			
	}
	
	private int listEmployeesMenu(){
		System.out.println("List:");
		System.out.println("-------------");
		System.out.println("1) All Employees");
		System.out.println("2) Managers");
		System.out.println("3) Sales Workers");
		System.out.println("4) Temp Workers");
		boolean goodInput = false;
	    int option=0;
	    do{
			try{
				option= input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
    	return option;
	}
	private void runListEmployeesMenu(){
		int option=listEmployeesMenu();
		while (option != 0){

            switch (option){
               case 1:    listEmployees();
                          break;
               case 2:    listManagers();
                          break;
               case 3:	  listSalesWorkers();
            	   		  break;
               case 4:    listTempWorkers();
               			  break;
            }
            
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            
            runMenu();
        }		
	}
	
	private void listEmployees(){
		int employeeNumber=0;
		String listEmployees = "";
		for (int i = 0; i < employees.size(); i++){
			employeeNumber=i+1;
			listEmployees+="Employee Number: "+ employeeNumber + "\n" + employees.get(i) + "\n";
		}
		System.out.print("\n"+listEmployees);
	}
	
	private void listManagers(){
		int employeeNumber=0;
		String listManagers = "";
		for (int i = 0; i < employees.size(); i++){
			if(employees.get(i) instanceof Manager){
			employeeNumber=i+1;
			listManagers+="Employee Number: "+ employeeNumber + "\n" + employees.get(i) + "\n";
			}
		}
		System.out.print("\n"+listManagers);
	}
	
	private void listSalesWorkers(){
		int employeeNumber=0;
		String listSalesWorker = "";
		for (int i = 0; i < employees.size(); i++){
			if(employees.get(i) instanceof SalesWorker){
			employeeNumber=i+1;
			listSalesWorker+="Employee Number: "+ employeeNumber + "\n" + employees.get(i) + "\n";
			}
		}
		System.out.print("\n"+listSalesWorker);
	}
	
	private void listTempWorkers(){
		int employeeNumber=0;
		String listTempWorkers = "";
		for (int i = 0; i < employees.size(); i++){
			if(employees.get(i) instanceof TempWorker){
			employeeNumber=i+1;
			listTempWorkers+="Employee Number: "+ employeeNumber + "\n" + employees.get(i) + "\n";
			}
		}
		System.out.print("\n"+listTempWorkers);
	}
	
	private int chooseEmployee(){
	    int positionInArray=0;
		if (employees.size() !=0){    		
    		boolean goodInput = false;
    	    do{
    			try{
    				positionInArray= validInt("Enter the employee number:", input.nextInt());
    				positionInArray-=1;
    				goodInput=true;
    			}
    			catch (Exception e){
    				input.nextLine();
    				System.out.println("Number required - you entered text");
    			}
    		}while(!goodInput);
		}
	    return positionInArray;
	}
	
	private int validInt(String prompt, int number)
	{
		do{
			System.out.print(prompt);
			number=input.nextInt();
		}while(number<=0);	        
	    return number;
	}
	
	private int editEmployeeMenu(int positionInArray){
		System.out.println("Would you like to edit:");
		System.out.println("-----------------------");
		System.out.println("1) Employee's first name");
		System.out.println("2) Employee's second name");
		System.out.println("3) Employee's hourly rate");
		if(employees.get(positionInArray) instanceof Manager){
			System.out.println("4) Manager Bonus");
		}
		else if(employees.get(positionInArray) instanceof SalesWorker){
			System.out.println("4) Sales Bonus");
		}
		boolean goodInput = false;
	    int option=0;
	    do{
			try{
				option= input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
    	return option;
	}
	
	private void runEditEmployeeMenu(){
		listEmployees();
		int positionInArray=chooseEmployee();
		int option=editEmployeeMenu(positionInArray);
		while (option != 0){

            switch (option){
               case 1:    editFirstName(positionInArray);
                          break;
               case 2:    editSecondName(positionInArray);
                          break;
               case 3:	  editHourlyRate(positionInArray);
            	   		  break;
               case 4:    if(employees.get(positionInArray) instanceof Manager){
            	   			editManagerBonus(positionInArray);
               			  }
               			  else if(employees.get(positionInArray) instanceof SalesWorker){
               				editSalesBonus(positionInArray);              
               			  }
               			  break;
            }
            
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            
            runMenu();
        }		
	}
	private void editFirstName(int positionInArray){
		input.nextLine();
		System.out.println("Enter correct first name:");
		String newName=input.nextLine();
		employees.get(positionInArray).setFirstName(newName);
	}
	private void editSecondName(int positionInArray){
		System.out.println("Enter correct surname:");
		String newName=input.nextLine();
		employees.get(positionInArray).setSecondName(newName);
	}
	private void editHourlyRate(int positionInArray){
		boolean goodInput = false;
	    double newHourlyRate=0;
	    do{
			try{
				do{
					System.out.println("Enter new hourly rate:");
					newHourlyRate= input.nextDouble();
				}while(newHourlyRate<0);
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
		employees.get(positionInArray).setHourlyRate(newHourlyRate);
	}
	private void editManagerBonus(int positionInArray){
		System.out.println("Enter new bonus:");
		boolean goodInput = false;
	    double newBonus=0;
	    do{
			try{
				newBonus= input.nextDouble();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
		if(employees.get(positionInArray)instanceof Manager){
			Manager manager=(Manager)employees.get(positionInArray);
			manager.setBonus(newBonus);
		}
		
	}
	private void editSalesBonus(int positionInArray){
		System.out.println("Enter new bonus(%):");
		boolean goodInput = false;
	    double newSalesBonus=0;
	    do{
			try{
				newSalesBonus= input.nextDouble();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
		if(employees.get(positionInArray)instanceof SalesWorker){
			SalesWorker sales=(SalesWorker)employees.get(positionInArray);
			sales.setSalesBonus(newSalesBonus);
		}
	}
	
	private void removeEmployee(){
    	listEmployees();    	
    	int positionInArray=chooseEmployee();
		if ((positionInArray < employees.size())&&(positionInArray>=0)){    	
			employees.remove(positionInArray);
			System.out.println("Employee Removed");
		}
		else{
			System.out.println("There is no employee with this number");
		}
    	
    }
	
	
	private int calculateSalaryMenu(){
		System.out.println("Salary Menu");
		System.out.println("-----------");
		System.out.println("1) Calculate Weekly Salary");
		System.out.println("2) Estimate Monthly Salary");
		System.out.println("3) Estimate Yearly Salary");
		System.out.println("-----------------------");
		System.out.println("0) Return to Main Menu");
		input.nextLine();
		boolean goodInput = false;
	    int option=0;
	    do{
			try{
				option= input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
    	return option;
	}
	
	private void runCalculateSalaryMenu(){
		listEmployees();
		int positionInArray=chooseEmployee();
		int option=calculateSalaryMenu();
		while (option != 0){

            switch (option){
               case 1:    calculateWeeklySalary(positionInArray);
                          break;
               case 2:    calculateMonthlySalary(positionInArray);
                          break;
               case 3:	  calculateYearlySalary(positionInArray);
            	   		  break;
            }
            
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            
            runCalculateSalaryMenu();
        }
		
	}
	
	private double numHours(){
		input.nextLine();
		System.out.println("How many hours has this Employee worked this week?");
		double numHours=0;
		boolean goodInput = false;
	    do{
			try{
				numHours= input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
	    return numHours;
	}
	
	private void calculateWeeklySalary(int positionInArray){
		double numHours=numHours();
	    double salary=employees.get(positionInArray).calculateSalary(numHours);
		System.out.println("This employees salary for the week is: "
				+salary);
		double weeklyTax=employees.get(positionInArray).calculateWeeklyTax(numHours);
		System.out.println("This employees tax deductions for this week is: "
				+weeklyTax);
		double salaryAfterDeduction=salary-weeklyTax;
		System.out.println("This employees salary after tax for this week is: "
				+salaryAfterDeduction);
	}	
	
	private void calculateMonthlySalary(int positionInArray){
		double numHours=numHours();
		double monthlySalary=employees.get(positionInArray).monthlySalary(numHours);
		System.out.println("This employees salary for the month is: "
				+monthlySalary);
		double monthlyTax=employees.get(positionInArray).calculateMonthlyTax(numHours);
		System.out.println("This employees tax deductions for this month is: "
				+monthlyTax);
		double salaryAfterDeduction=monthlySalary-monthlyTax;
		System.out.println("This employees salary after tax for this month is: "
				+salaryAfterDeduction);
	}
	
	private void calculateYearlySalary(int positionInArray){
		double numHours=numHours();
		double yearlySalary=employees.get(positionInArray).yearlySalary(numHours);
		System.out.println("This employees salary for the year is: "
				+yearlySalary);
		double yearlyTax=employees.get(positionInArray).calculateYearlyTax(numHours);
		System.out.println("This employees tax deductions for this year is: "
				+yearlyTax);
		double salaryAfterDeduction=yearlySalary-yearlyTax;
		System.out.println("This employees salary after tax for this year is: "
				+salaryAfterDeduction);
	}
		
	private void load() throws Exception{
		employees=HandleXML.read("employees.xml");
	}
	
	private void save() throws Exception{
		HandleXML.write(employees, "employees.xml");
	}
	
	private int deptMenu(){
		input.nextLine();
		System.out.println("Department Menu");
		System.out.println("---------------");
		System.out.println("1) Add an employee to the department");
		System.out.println("2) List employees in the deparment");
		System.out.println("3) Edit eployee's details");
		System.out.println("4) Remove an employee from the department");
		System.out.println("-----------------------------------------");
		System.out.println("0) Return to main menu");
		boolean goodInput = false;
	    int option=0;
	    do{
			try{
				option= input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
    	return option;
	}
	private void runDeptMenu(){
		int option=deptMenu();
		while (option != 0){
			int positionInArray=chooseDept();
			loadDept(positionInArray);
            switch (option){
               case 1:    addToDept(positionInArray);
               			  saveDept(positionInArray);
                          break;
               case 2:    listDept(positionInArray);
               			  saveDept(positionInArray);
                          break;
               case 3:    editDeptEmployeeDetails(positionInArray);
                          saveDept(positionInArray);
               case 4:	  removeFromDept(positionInArray);
               			  saveDept(positionInArray);
            	   		  break;
               case 0:    runMenu();
               			  break;
            }            
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();            
            option=deptMenu();
        }
	}
	
	private int chooseDept(){
		int positionInArray=0; 
		if (employees.size()>=0){
			input.nextLine();
			System.out.print("\nChoose a department manager:");
			listManagers();
			boolean goodInput = false;		
			int choice= 0;
			do{
			try{
				choice=input.nextInt();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
			}	while(!goodInput);
			positionInArray=choice-1;
		}
		return positionInArray;
	}
	
	private void addToDept(int positionInArray){
		if(employees.get(positionInArray)instanceof Manager){
			Manager manager=(Manager)employees.get(positionInArray);			
			addDeptEmployee(manager);
			System.out.println(manager.listDept());
		}
	}
	
	private void addDeptEmployee(Manager manager){
		listSalesWorkers();
		listTempWorkers();
		input.nextLine();
		System.out.println("\nEnter employee number would you like to add?");
		int positionInArray=chooseEmployee();
		if (positionInArray>=0){
			manager.addDeptEmployee(employees.get(positionInArray));
			
		}
	}
	private void listDept(int positionInArray){		
		if((employees.get(positionInArray)instanceof Manager)&&(positionInArray>=0)){
				Manager manager=(Manager)employees.get(positionInArray);
				System.out.println(employees.get(positionInArray));
				System.out.println(manager.listDept());
			}
	}
	
	private void editDeptEmployeeDetails(int positionInArray){
		if(employees.get(positionInArray)instanceof Manager){
				Manager manager=(Manager)employees.get(positionInArray);
				System.out.println(manager.listDept());
				int index=chooseEmployee();
				runEditDeptEmployeeMenu(manager,index);
		}
	}

	private void runEditDeptEmployeeMenu(Manager manager, int index){
		int option=editEmployeeMenu(index);
		while (option != 0){

            switch (option){
               case 1:    editDeptFirstName(manager,index);
                          break;
               case 2:    editDeptSecondName(manager,index);
                          break;
               case 3:	  editDeptHourlyRate(manager,index);
            	   		  break;
               case 4:    if(employees.get(index) instanceof SalesWorker){
               				editDeptSalesBonus(manager,index);              
               			  }
               			  break;
            }
            
            System.out.println("\nPress any key to continue...");
            input.nextLine();
            input.nextLine();
            
            runDeptMenu();
        }		
	}
	
	
	private void editDeptFirstName(Manager manager, int index){
		input.nextLine();
		System.out.println("Enter correct first name:");
		String newName=input.nextLine();
		manager.getDept().get(index).setFirstName(newName);
	}
	private void editDeptSecondName(Manager manager, int index){
		System.out.println("Enter correct surname:");
		String newName=input.nextLine();
		manager.getDept().get(index).setSecondName(newName);
	}
	private void editDeptHourlyRate(Manager manager, int index){
		boolean goodInput = false;
	    double newHourlyRate=0;
	    do{
			try{
				do{
					System.out.println("Enter new hourly rate:");
					newHourlyRate= input.nextDouble();
				}while(newHourlyRate<0);
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
	    manager.getDept().get(index).setHourlyRate(newHourlyRate);
	}
	private void editDeptSalesBonus(Manager manager, int index){
		System.out.println("Enter new bonus(%):");
		boolean goodInput = false;
	    double newSalesBonus=0;
	    do{
			try{
				newSalesBonus= input.nextDouble();
				goodInput=true;
			}
			catch (Exception e){
				input.nextLine();
				System.out.println("Number required - you entered text");
			}
		}while(!goodInput);
		if(manager.getDept().get(index)instanceof SalesWorker){
			SalesWorker sales=(SalesWorker)manager.getDept().get(index);
			sales.setSalesBonus(newSalesBonus);
		}
	}
	
	private void removeFromDept(int positionInArray){
		if(employees.get(positionInArray)instanceof Manager){
				Manager manager=(Manager)employees.get(positionInArray);
				System.out.println(manager.listDept());
				int index=chooseEmployee();	    		
		    		if (index>=0){    	
		    			manager.getDept().remove(index);
		    			System.out.println("Employee removed from department");
		    		}
		    		else{
		    			System.out.println("There is no employee stored in this position!");
		    		}
			}
	}	
	
	private void saveDept(int positionInArray){
		if((employees.get(positionInArray)instanceof Manager)&&(positionInArray>=0)){
			Manager manager=(Manager)employees.get(positionInArray);
			try{
	   			  manager.save();
 			  }
 			  catch(Exception e){
 				  System.out.println("Error writing to file: " + e);
 			  }
		}
	}
	private void loadDept(int positionInArray){
		if((employees.get(positionInArray)instanceof Manager)&&(positionInArray>=0)){
			Manager manager=(Manager)employees.get(positionInArray);
			try{
		  			  manager.load();
	  		  }
	  		  catch(Exception e){
	  			  System.out.println("Error reading from file: " + e);
	  		  }
		}
		
	}
}
