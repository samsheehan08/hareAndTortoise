
public abstract class Employee 
{
	private String firstName;
	private String secondName;
	private double hourlyRate;
	final static double NORMAL_WORKWEEK = 37.5;
	final static double LOW_TAX_BRACKET=34000;
	
	public Employee(String firstName, String secondName, double hourlyRate){
		this.firstName=firstName;
		this.secondName=secondName;
		if(hourlyRate>=0){
			this.hourlyRate=hourlyRate;
		}
		else{
			this.hourlyRate=0;
		}
	}
	
	public Employee(){
		
	}

	public void setFirstName(String firstName){
		this.firstName=firstName;
	}
	public void setSecondName(String secondName){
		this.secondName=secondName;
	}
	public void setHourlyRate(double hourlyRate){
		if(hourlyRate>=0){
			this.hourlyRate=hourlyRate;
		}
	}
	
	public String getFirstName(){
		return firstName;
	}
	public String getSecondName(){
		return secondName;
	}
	public double getHourlyRate(){
		return hourlyRate;
	}
	
	public  double calculateOvertime (double numHours){
		double overtimeHours=numHours-NORMAL_WORKWEEK;		
		double overtime=overtimeHours*(hourlyRate*2);
		return overtime;
	}
	
	public abstract double calculateSalary(double numHours);
	
	public double yearlySalary(double numHours){
		double salary=calculateSalary(numHours);
		salary*=52;
		return salary;
	}
	public double monthlySalary(double numHours){
		double salary=yearlySalary(numHours);
		salary/=12;
		return salary;
	}
	public double calculateYearlyTax(double numHours){
		double yearlySalary=yearlySalary(numHours);
		if(yearlySalary>LOW_TAX_BRACKET){
			double highTaxBracket=yearlySalary-LOW_TAX_BRACKET;
			double tax=LOW_TAX_BRACKET*20/100+highTaxBracket*40/100;
			return tax;
		}
		else{
			double tax=yearlySalary*20/100;
			return tax;
		}
	}
	public double calculateMonthlyTax(double numHours){
		double yearlyTax=calculateYearlyTax(numHours);
		double tax=yearlyTax/12;
		return tax;
	}
	public double calculateWeeklyTax(double numHours){
		double yearlyTax=calculateYearlyTax(numHours);
		double tax=yearlyTax/52;
		return tax;
	}
	
	public String toString(){
		return  "\nEmployee's First Name: " + firstName
                + "\nEmployee's Second Name: " + secondName
                + "\nHourly Rate: " + hourlyRate;
	}

}
