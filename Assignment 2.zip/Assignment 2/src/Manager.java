import java.util.ArrayList;
import java.util.List;
public class Manager extends Employee
{
	private List<Employee> deptEmployees;
	private double managerBonus;
	
	public Manager(String firstName, String secondName, double hourlyRate, double managerBonus){
		super(firstName, secondName, hourlyRate);
		deptEmployees = new ArrayList<Employee>();
		if(managerBonus>=0){
			this.managerBonus=managerBonus;
		}
		else{
			this.managerBonus=0;
		}
	}
	
	public Manager(){
		super();
	}
	
	public void addDeptEmployee(Employee employee){
		deptEmployees.add(employee);
	}
	
	public List<Employee> getDept(){
		return deptEmployees;
	}
	public void setDept(List<Employee> deptEmployees){
		this.deptEmployees=deptEmployees;
	}

	public double getBonus() {
		return managerBonus;
	}
	public void setBonus(double managerBonus) {
		if(managerBonus>=0){
			this.managerBonus=managerBonus;
		}
		
	}
	public int numberInDept(){
		return deptEmployees.size();
	}
	
	public double calculateSalary(double numHours){
		double hourlyRate= getHourlyRate();
		double salary=0;
		if(numHours>NORMAL_WORKWEEK){
			salary=hourlyRate*NORMAL_WORKWEEK;
			salary+=calculateOvertime(numHours);
			salary+=managerBonus;
		}
		else{
			salary=numHours*hourlyRate;
			salary+=managerBonus;
		}
		return salary;
		
	}	
	public String listDept(){
		int employeeDeptNumber=0;
		String listDeptEmployees = "";
		for (int i = 0; i <numberInDept(); i++){
			employeeDeptNumber=i+1;
			listDeptEmployees+="Employee's Department Number: "+ employeeDeptNumber + "\n" + deptEmployees.get(i) + "\n";
		}
		return listDeptEmployees;
	}
	
	public void load() throws Exception{
		deptEmployees=HandleXML.read("deptEmployees.xml");
	}
	
	public void save() throws Exception{
		HandleXML.write(deptEmployees, "deptEmployees.xml");
	}
	
	public String toString(){
		return  "Manager"
				+ "\nEmployee's First Name: " + getFirstName()
                + "\nEmployee's Second Name: " + getSecondName()
                + "\nHourly Rate: " + getHourlyRate()
				+ "\nManager Bonus: " + managerBonus;
	}

	

}
