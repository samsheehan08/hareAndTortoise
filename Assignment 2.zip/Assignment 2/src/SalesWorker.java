
public class SalesWorker extends Employee
{
	
	private double salesBonus;//this should be a %
	
	public SalesWorker(String firstName, String secondName, double hourlyRate, double salesBonus){
		super(firstName, secondName, hourlyRate);
		if ((salesBonus>0)&&(salesBonus<20)){
			this.salesBonus=salesBonus;
		}
		else{
			this.salesBonus=0;
		}
	}
	
	public SalesWorker(){
		super();
	}
	
	public void setSalesBonus(double salesBonus){
		if((salesBonus>=0)&&(salesBonus<=20)){
			this.salesBonus=salesBonus;
		}
	}
	public double getSalesBonus(){
		return salesBonus;
	}
	
	
	
	public double calculateSalary(double numHours){
		double salary=0;
		double hourlyRate=getHourlyRate();
		if(numHours>NORMAL_WORKWEEK){
			salary=hourlyRate*NORMAL_WORKWEEK;
			salary+=calculateOvertime(numHours);
		}
		else{
			salary=numHours*hourlyRate;
		}
		double bonus;
		if (salesBonus>5){
			bonus=(salesBonus/100)*salary;
		}
		else{
			bonus=0;
		}
		salary+=bonus;
	
		return salary;
	}
	
	public String toString(){
		return  "Sales Worker"
				+ "\nEmployee's First Name: " + getFirstName()
                + "\nEmployee's Second Name: " + getSecondName()
                + "\nHourly Rate: " + getHourlyRate()
				+ "\nSales Bonus: " + salesBonus + "%";
	}

}
