
public class TempWorker extends Employee
{
	public TempWorker(String firstName, String secondName, double hourlyRate){
		super(firstName, secondName, hourlyRate);
	}	
	public TempWorker(){
		super();
	}
	
	public double calculateSalary(double numHours){
		double salary=0;
		double hourlyRate=getHourlyRate();
		if(numHours>NORMAL_WORKWEEK){
			salary=hourlyRate*NORMAL_WORKWEEK;
			salary+=calculateOvertime(numHours);
		}
		else{
			salary=numHours*hourlyRate;
		}
		return salary;
	}
	
	public String toString(){
		return  "Temp Worker"
				+ "\nEmployee's First Name: " + getFirstName()
                + "\nEmployee's Second Name: " + getSecondName()
                + "\nHourly Rate: " + getHourlyRate();
	}
	
}
